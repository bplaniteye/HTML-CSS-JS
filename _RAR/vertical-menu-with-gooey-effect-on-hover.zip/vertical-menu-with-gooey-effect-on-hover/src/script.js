feather.replace()
//https://twitter.com/One_div